# MovieLens-Recommender-System
how does Spotify, Amazon, and Netflix generate recommendations for their users?  we will explore two types of recommender systems: 1) collaborative filtering, and 2) content-based filtering. We built our own recommendation system using the MovieLens dataset in Python.
